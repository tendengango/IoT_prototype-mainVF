<pre>
웹브라우저에서 시간을 표시할 수 있도록 한다.

clock-1.html   - 시간 정보를 표시하는 방법 확인
clock-2.html   - 매초 시간을 표시하는 방법 확인
clock-3.html   - 출력 꾸미기
clock-4.html   - 년월일 추가하기
clock-5.html   - 요일 추가하기
</pre>