from turtle import *
shape('turtle')
color('red','yellow')
for i in range(180):
   forward(i)
   left(90)
