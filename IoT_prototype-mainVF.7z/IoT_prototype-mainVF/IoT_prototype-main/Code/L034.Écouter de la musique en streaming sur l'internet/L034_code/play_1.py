import os

cmd = "mpg123 -f 60000 http://ice1.somafm.com/u80s-128-mp3"
print(os.system(cmd))

